package com.example.callrec

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var latestFile: File? = null
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var stop: Button
    private lateinit var play: Button
    private var recording = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 60, 36, 30); gravity = Gravity.CENTER_HORIZONTAL }
        val title = TextView(this).apply { text = "CallRec — тест микрофона"; textSize = 24f }
        status = TextView(this).apply { text = "Запись пока не запущена. Используй громкую связь для теста."; textSize = 16f; setPadding(0, 24, 0, 24) }
        start = Button(this).apply { text = "Начать запись"; setOnClickListener { requestOrStart() } }
        stop = Button(this).apply { text = "Остановить"; isEnabled = false; setOnClickListener { stopRecording() } }
        play = Button(this).apply { text = "Прослушать последнюю"; isEnabled = false; setOnClickListener { playLast() } }
        val note = TextView(this).apply { text = "Только ручная запись. Не скрывает факт записи. Android может блокировать микрофон во время звонка. Держи приложение открытым."; setPadding(0, 28, 0, 0) }
        listOf(title, status, start, stop, play, note).forEach { layout.addView(it) }
        setContentView(layout)
    }

    private fun requestOrStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
        } else startRecording()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startRecording()
        else status.text = "Нужно разрешение на микрофон"
    }

    private fun startRecording() {
        if (recording) return
        val folder = File(filesDir, "recordings").apply { mkdirs() }
        val name = "recording_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.m4a"
        val file = File(folder, name)
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            latestFile = file
            recording = true
            start.isEnabled = false; stop.isEnabled = true; play.isEnabled = false
            status.text = "Идёт запись: ${file.name}"
        } catch (e: Exception) {
            recorder?.release(); recorder = null; rCleanup(file)
            status.text = "Запись не удалась: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun rCleanup(file: File) { if (file.exists()) file.delete() }

    private fun stopRecording() {
        if (!recording) return
        var ok = true
        try { recorder?.stop() } catch (e: RuntimeException) { ok = false; latestFile?.let(::rCleanup) }
        recorder?.release(); recorder = null; recording = false
        start.isEnabled = true; stop.isEnabled = false; play.isEnabled = ok
        status.text = if (ok) "Сохранено: ${latestFile?.name}" else "Запись повреждена или аудио заблокировано системой"
    }

    private fun playLast() {
        val file = latestFile ?: return
        player?.release()
        try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { it.release(); player = null; status.text = "Воспроизведение завершено" }
                prepare(); start()
            }
            status.text = "Воспроизводится: ${file.name}"
        } catch (e: Exception) { status.text = "Не удалось воспроизвести: ${e.message}" }
    }

    override fun onDestroy() {
        if (recording) stopRecording()
        player?.release(); player = null
        super.onDestroy()
    }
}
